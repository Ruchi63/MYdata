package day4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DemoPageFactory
{
	public DemoPageFactory(WebDriver wd)
	{
		PageFactory.initElements(wd, this);
	}
	
	//repository
	//@FindBy (id="txtUsername") WebElement uname;
	//@FindBy (id="txtPassword") WebElement pword;
	//@FindBy (id="btnLogin") WebElement login;
	
	WebElement txtUsername;
	WebElement txtPassword;
	WebElement btnLogin;
	
	//method
	public void username(String un)
	{
		//uname.sendKeys(un);
		txtUsername.sendKeys(un);
	}
	public void password(String pw)
	{
		//pword.sendKeys(pw);
		txtPassword.sendKeys(pw);
	}
	public void clklogin()
	{
		//login.click();
		btnLogin.click();
	}
}
