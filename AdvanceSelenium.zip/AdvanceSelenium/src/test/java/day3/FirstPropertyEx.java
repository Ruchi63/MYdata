package day3;

import java.io.FileInputStream;

import java.util.Properties;

import org.testng.annotations.Test;

public class FirstPropertyEx {
  @Test
  public void propertyFileEx() throws Exception
  {
	  Properties prop = new Properties();
	  prop.load(new FileInputStream("src\\test\\resources\\PropertyFile\\Demo.property"));
	  
	  String data = prop.getProperty("url");
	  System.out.println(data);
  }
}
