package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import helper.BaseClass;

public class DemoAction extends BaseClass
{
  @Test
  public void draganddrop() 
  {
	  wd.get("https://www.globalsqa.com/demo-site/draganddrop/");
	  wd.switchTo().frame(wd.findElement(By.xpath("//*[@id=\"post-2669\"]/div[2]/div/div/div[1]/p/iframe")));
	  
	  //source
	  WebElement drag1fromimage1 = wd.findElement(By.xpath("//*[@id=\"gallery\"]/li[4]/img"));
	  
	  //target
	  WebElement dropimage1to = wd.findElement(By.xpath("//*[@id=\"trash\"]"));
	  
	  Actions builder = new Actions(wd);
	  
	  Action drop1Image1 = builder.clickAndHold(drag1fromimage1)
			  					.moveToElement(dropimage1to)
			  					.release(dropimage1to)
			  					.build();
	  
	  drop1Image1.perform();
  }
}
