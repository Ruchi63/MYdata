package day2;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import helper.BaseClass;

public class DemoWindowHandle extends BaseClass
{
  @Test
  public void faWindow()
  {
	  wd.get("http://frontaccounting.squadinfotech.in");
	  wd.findElement(By.name("user_name_entry_field")).sendKeys("frontuser11");
	  wd.findElement(By.name("password")).sendKeys("frontuser11");
	  Select comp = new Select(wd.findElement(By.name("company_login_name")));
	  comp.selectByVisibleText("Squad_MT_OL-50");
	  wd.findElement(By.name("SubmitUser")).click();
	  
	  //sales quotation entry
	  wd.findElement(By.xpath("/html/body/table[1]/tbody/tr/td/table[1]/tbody/tr/td/div[2]/table/tbody/tr[1]/td/table/tbody/tr[2]/td[1]/a[1]")).click();
	  
	  String PID = wd.getWindowHandle();//getting id of current highlighted tab/win
	  System.out.println("Parent window id==== "+ PID);
	  
	//445,245,856.20
	  wd.findElement(By.xpath("/html/body/table[1]/tbody/tr/td/table[1]/tbody/tr/td/div[2]/form/center[1]/table/tbody/tr/td[2]/table/tbody/tr[1]/td[2]/a")).click();
  
	  //set<String>-->adv--->will not have duplicate value
	  Set<String> allwin = wd.getWindowHandles();//getting id of current highlighted tab/win
	  
	  for(String W:allwin)
	  {
		  	wd.switchTo().window(W);
		  	System.out.println(wd.getTitle());
		  	
		  	if(!(W.equals(PID)))//checking child window or not
		  	{
		  		Select s = new Select(wd.findElement(By.name("customer_id")));
		  		s.selectByVisibleText("Donald Easter");
		  		wd.manage().window().maximize();
		  		wd.close();
		  	}
	   }
	  	wd.switchTo().window(PID);
	  	wd.findElement(By.linkText("Logout")).click();

	  }
}
