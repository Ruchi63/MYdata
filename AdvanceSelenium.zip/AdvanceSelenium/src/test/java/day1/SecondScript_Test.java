package day1;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import helper.BaseClass;

public class SecondScript_Test extends BaseClass
{
  @Test(description="Print all values of DropDown")
  public void dropdownElement()
  {
	 // wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//  wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  wd.get("https://blazedemo.com/");
	  WebElement from = wd.findElement(By.name("fromPort"));
	  Select s = new Select(from);
	  
	  List<WebElement> alloptions = s.getOptions();//is used to get all options from dropdown list
	  for(int i=0;i<alloptions.size();i++)
	  {
		  System.out.println(alloptions.get(i).getText());
	  }
  }
}
