package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import helper.BaseClass;

public class DemoScroll extends BaseClass
{
  @Test(description="Scrolling")
  public void scrollMethod() throws Exception
  {
	  wd.get("https://www.selenium.dev/downloads/");
	  //	https://www.album.alexflueras.ro/index.php for left & right scrolling

	  JavascriptExecutor js = (JavascriptExecutor)wd;
	//  WebElement e = wd.findElement(By.linkText("Chrome"));
	//  js.executeScript("arguments[0].scrollIntoView()", e);
	  
	  //***********************************************************************
	  
	  //js.executeScript("window.scrollTo(0,document.body.scrollHeight)");//Bottom of page
	  //Thread.sleep(2000);
	  //js.executeScript("window.scrollTo(0,-document.body.scrollHeight)");//top of page
	  
	  //****************************************************************************
	  
	  //js.executeScript("window.scrollBy(0,3000)");//down
	  //Thread.sleep(2000);
	  //js.executeScript("window.scrollBy(0,-3000)");//up
	  
	  //**********************************************************************
	 // js.executeScript("window.scrollBy(3000,0)");//right
	 // Thread.sleep(2000);
	 // js.executeScript("window.scrollBy(-3000,0)");//left
	  
  }
}
