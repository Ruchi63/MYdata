package day6;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class DemoExtent 
{
	ExtentReports ext;
	ExtentTest tc1;
	WebDriver wd;
	@BeforeTest
	public void rep() 
	{
		 ext = new ExtentReports();
		 ext.attachReporter(new ExtentHtmlReporter("report.html"));
		 tc1  =ext.createTest("BlazeDemo Test");
		  System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\Drivers\\chromedriver.exe");
		  wd = new ChromeDriver();
		  tc1.info("Starting Browser");
		}
	  @Test
  public void exExtentReport() 
  {
	  wd.manage().window().maximize();
	  tc1.info("Maximised window ");
	  
	  wd.get("https://blazedemo.com/");
	  tc1.info("Opening URL");
	  
	  if(wd.getTitle().equals("Blaze"))
	  {
		  tc1.log(Status.PASS, "Navigated Successfully");
		  
	  }
	  else
	  {
		  tc1.log(Status.FAIL, "Navigated unsuccessfully");
	  }
  }
  @AfterTest
  public void clrep()
  {
	  tc1.info("Close browser");
	wd.quit();
	ext.flush();
}
}
