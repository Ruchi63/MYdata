package day6;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import helper.BaseClass;

public class DemoUpload extends BaseClass
{
  @Test
  public void demoFile() 
  {
	  
	  wd.get("https://www.monsterindia.com/seeker/registration");
	  
	  wd.findElement(By.xpath("//*[@id=\"file-upload\"]")).sendKeys("C:\\Users\\91992\\Desktop\\DemoFile.txt");
	  System.out.println("File uploaded");
	  
  }
}
