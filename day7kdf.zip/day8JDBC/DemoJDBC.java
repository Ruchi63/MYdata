package day8JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoJDBC {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		Connection con = DriverManager.getConnection("jdbc:mysql://148.72.215.41:3306/testingdb","testuser","testuser");
		Statement st = con.createStatement();
		ResultSet res = st.executeQuery("select * from 71OHM");
		
		
		String un,pw;
		while(res.next())
		{
			un=res.getString(1);
			pw=res.getString(2);
			
			System.out.println(un + "    " +pw);
			
			wd.findElement(By.name("username")).sendKeys(un);
			wd.findElement(By.name("password")).sendKeys(pw);
			wd.findElement(By.cssSelector("button[type=submit]")).click();
		}

	}

}
