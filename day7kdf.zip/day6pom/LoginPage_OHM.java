package day6pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage_OHM
{
	WebDriver wd;
	public LoginPage_OHM(WebDriver wd)
	{
		this.wd=wd;
	}
	//repository of webelement
	By uname = By.name("username");
	By pword = By.name("password");
	By button = By.xpath("//button[@type='submit']");
	
	//repository method
	public void url()
	{
		wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}
	public void username(String un)
	{
		wd.findElement(uname).sendKeys(un);
	}
	public void password(String pw)
	{
		wd.findElement(pword).sendKeys(pw);
	}
	public void login()
	{
		wd.findElement(button).click();
	}
	public void loginProcess(String un , String pw)
	{
		url();
		username(un);
		password(pw);
		login();
		
	}
}
