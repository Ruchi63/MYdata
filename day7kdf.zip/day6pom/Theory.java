package day6pom;

public class Theory
{
/*	POM---->	Page Object Model
 * 	POM is a design pattern
 * 	can be implemented in any framework
 * 	Framework can be created in more structured way
 * 	In POM, we create Repository of webelement & code 
 * 			acting on these webelement i.e. methods
 * 	[REPOSITORY---> common storage for storing Object]
 * 	Page wise distribution in POM
 * 
 * 
 * 	Adv:
 * 		REusability of code
 * 		code maintenance will be easy
 * 		Easily find out error location
 * 		Length of code will reduce
 * 
 * 	Implement POM by 2 ways
 * 		'By' class
 * 		'PageFactory' class
 * 
 */
}
