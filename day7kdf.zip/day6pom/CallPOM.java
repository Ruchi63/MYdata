package day6pom;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CallPOM {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		LoginPage_OHM lp = new LoginPage_OHM(wd);
		LogoutPage_OHM lg = new LogoutPage_OHM(wd);
		
		/*lp.username("admin");
		lp.password("admin123");
		lp.login();
		
		lg.pauldp();
		lg.logout();
*/
		
		lp.loginProcess("admin", "admin123");
		lg.logoutProcess();
	}

}
