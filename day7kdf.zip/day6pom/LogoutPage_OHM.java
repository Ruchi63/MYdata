package day6pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class LogoutPage_OHM 
{
	WebDriver wd;
	public LogoutPage_OHM(WebDriver wd)
	{
		this.wd=wd;
	}
	
	//Repository of webelement
	By paul = By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[2]/ul/li/span/i");
	By lgout = By.linkText("Logout");
	
	//Repository method
	public void pauldp()
	{
		wd.findElement(paul).click();
	}
	public void logout()
	{
		wd.findElement(lgout).click();
	}
	public void logoutProcess()
	{
		pauldp();
		logout();
	}
}
