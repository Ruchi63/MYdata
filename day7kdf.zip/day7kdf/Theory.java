package day7kdf;

public class Theory 
{
/*	Keyword driven framework
 * 	1]	which is driven by keyword is called as KDF
 * 	2]	keyword has some predefined meaning
 * 			eg:- int ---> can be used to store integer type of data
 * 	3]	keywords are used to represent actions/step which
 * 			are involved in script writing
 * 	4]	This sheet is created by sr. OR exp. tester & will
 * 			be given to jr. tester for testing purpose
 * 	5]	keywords in excel sheet & number of methods in
 * 			repository should be same & name also should be same 
 * 
 */
}
