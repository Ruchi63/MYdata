package day7kdf;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import day6pom.LoginPage_OHM;
import day6pom.LogoutPage_OHM;

public class DemoKDF {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		FileInputStream fis = new FileInputStream("C:\\Users\\91992\\eclipse-workspace\\Automation71\\ExcelFile.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("KeyOHM");
		
		LoginPage_OHM lp = new LoginPage_OHM(wd);
		LogoutPage_OHM lg = new LogoutPage_OHM(wd);
		
		
		for(int i=1;i<=sh.getLastRowNum();i++)
		{
			XSSFRow rw = sh.getRow(i);
			XSSFCell key = rw.getCell(1);
			
			System.out.println(key);
			
			switch (key.toString()) {
			case "url":
				lp.url();
				break;
			case "username":
				lp.username("admin");
				break;
			case "password":
				lp.password("admin123");
				break;
			case "login":
				lp.login();
				break;
			case "paul":
				lg.pauldp();
				break;
			case "logout":
				lg.logout();
				break;
				
				
			default:
				System.out.println("Invalid key");
				break;
			}
		}
	
	}

}
