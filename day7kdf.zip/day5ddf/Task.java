package day5ddf;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTableColumn;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.helpers.XSSFColumnShifter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Task {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("http://frontaccounting.squadinfotech.in/");
		
		FileInputStream fis = new FileInputStream("C:\\Users\\91992\\eclipse-workspace\\Automation71\\ExcelFile.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		
		wd.findElement(By.name("user_name_entry_field")).sendKeys("fauser25");
		wd.findElement(By.name("password")).sendKeys("fauser25");
		
		Select comp = new Select(wd.findElement(By.name("company_login_name")));
		comp.selectByVisibleText("Testing_Batch");
		
		wd.findElement(By.name("SubmitUser")).click();
		
	
		
		wd.findElement(By.linkText("Purchases")).click();
		List<WebElement>pmenu=wd.findElements(By.className("menu_option"));
		for(int i=0;i<pmenu.size();i++)
		{
			XSSFRow rw = sh.createRow(1);
			XSSFCell res = rw.createCell(0);
			
			System.out.println(pmenu.get(i).getText());
			res.setCellValue(pmenu.get(i).getText());
		}
		
		wd.findElement(By.linkText("Sales")).click();
		List<WebElement>smenu=wd.findElements(By.className("menu_option"));
		int l  = smenu.size();
		System.out.println(l);
		for(int j=0;j<l;j++)
		{
			
			XSSFRow rw = sh.createRow(2);
			XSSFCell res = rw.createCell(3);
			
			System.out.println(smenu.get(j).getText());
			res.setCellValue(smenu.get(j).getText());
		}
		//fis.close();
		FileOutputStream fos = new FileOutputStream("C:\\Users\\91992\\eclipse-workspace\\Automation71\\ExcelFile.xlsx");
		wb.write(fos);
	}

}
