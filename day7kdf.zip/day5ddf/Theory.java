package day5ddf;

public class Theory 
{
/*	FrameWork:-
 * 			is a structure,achieve quality product
 * 			without framework, we place code as well data in same script
 * 				which is not readable nor reusable
 * 
 * 	Types of framework
 * 
 * 		Data driven framework
 * 		keyword driven framework
 * 		behavior driven framework**** CUCUMBER
 * 		hybrid driven framework
 * 		
 * 		testNg	
 * 
 * 
 * 
 * 			DDF--->
 * 		which is driven by data is ddf
 * 		In ddf, we are going to separate data from script
 * 			data will be other location & script will be at 
 * 			another location
 * 		To test application with multiple set of data we have
 * 			to use this framework
 * 		In script instead of actual credential we will use variable at sendKeys(un)
 * 		FileInputStream class---> use to read a file
 * 
 * 			
 * 		.xls
 * 		.xlsx
 * 
 * 
 * 		File
 * 		WorkBook
 * 		Sheet--->Name OR Index
 * 		Row---->Index
 * 		Cell---->Index
 * 
 * 
 * 
 * 		To actually read data from excel file, we have to use POI
 * 			Poor Obfuscation Implementation
 * 		apache product
 * 		available in jar format
 * 		use to perform read & write operation
 * 		
 * 		Interface--->WorkBook...Sheet...Row..Cell
 * 	
 * 		.xls--->class--->HSSFWorkBook...HSSFSheet...HSSFRow....HSSFCell
 * 		.xlsx--->class--->XSSFWorkBook...XSSFSheet...XSSFRow...XSSFCell	
 * 
 */
}
