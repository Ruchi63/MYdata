package day5ddf;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WriteOHM {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
		FileInputStream fis = new FileInputStream("C:\\Users\\91992\\eclipse-workspace\\Automation71\\ExcelFile.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("WriteData");
		
		for(int i=1;i<=sh.getLastRowNum();i++)
		{
			XSSFRow rw = sh.getRow(i);
			XSSFCell un = rw.getCell(0);
			XSSFCell pw = rw.getCell(1);
			XSSFCell res = rw.createCell(2);//create cell at specified index
			
			System.out.println(un +"     "+pw);
			
			wd.findElement(By.name("username")).sendKeys(un.toString());
			wd.findElement(By.name("password")).sendKeys(pw.toString());
			wd.findElement(By.cssSelector("button[type=submit]")).click();
			try 
			{
				wd.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[2]/ul/li/span/i")).click();
				
				wd.findElement(By.linkText("Logout")).click();
			
				System.out.println("Valid");
				res.setCellValue("Valid");
			} 
			catch (Exception e) 
			{
				System.out.println("Invalid");
				res.setCellValue("Invalid");
			}
		
		}
		fis.close();
		FileOutputStream fos = new FileOutputStream("C:\\Users\\91992\\eclipse-workspace\\Automation71\\ExcelFile.xlsx");
		wb.write(fos);

	}

}
