package day5ddf;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadOHM {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
		FileInputStream fis = new FileInputStream("C:\\Users\\91992\\eclipse-workspace\\Automation71\\ExcelFile.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("ReadData");
		
		for(int i=1;i<=sh.getLastRowNum();i++)
		{
			XSSFRow rw = sh.getRow(i);
			XSSFCell un = rw.getCell(0);
			XSSFCell pw = rw.getCell(1);
			
			System.out.println(un +"     "+pw);
			
			wd.findElement(By.name("username")).sendKeys(un.toString());
			wd.findElement(By.name("password")).sendKeys(pw.toString());
			wd.findElement(By.cssSelector("button[type=submit]")).click();
		
		}
	}

}
