package day9testNg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DemoAssert 
{
	//Assertion--->is to verify that that expected result & actual result are matching
			// or not
  @Test
  public void assertGoogle()
  {
	  System.setProperty("webdriver.chrome.driver", "./chromedriver");
		WebDriver wd = new ChromeDriver();
		wd.get("https://www.google.com/");
		
		String ExpectedTitle = "Googles";//if there is no  matching result then will get as FAIL
		//String ExpectedTitle = "Google";if there is matching result then will get as PASS
		String ActualTitle = wd.getTitle();
		
		Assert.assertEquals(ActualTitle, ExpectedTitle);
		System.out.println("Actual title of webpage----> " + ActualTitle);
		
  }
}
