package day9testNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class TwoApp {
  @Test(groups = {"blazeDemo"})
  public void blazeDemo()
  {
	  System.setProperty("webdriver.chrome.driver", "./chromedriver");
		WebDriver wd = new ChromeDriver();
		wd.get("https://blazedemo.com/");
  }
   @Test(groups = {"FrontAccounting"})
  public void frontAccounting()
  {
	  System.setProperty("webdriver.chrome.driver", "./chromedriver");
		WebDriver wd = new ChromeDriver();
		wd.get("http://frontaccounting.squadinfotech.in/");
		wd.findElement(By.name("user_name_entry_field")).sendKeys("frontuser11");
		wd.findElement(By.name("password")).sendKeys("frontuser11");
		Select s = new Select(wd.findElement(By.name("company_login_name")));
		s.selectByVisibleText("Squad_MT_OL-50");
		wd.findElement(By.name("SubmitUser")).click();
  }
}
