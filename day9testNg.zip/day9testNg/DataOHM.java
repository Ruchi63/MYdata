package day9testNg;

import org.testng.annotations.Test;

import day7POM.OperationOHM_LoginPage;
import day7POM.OperationOHM_LogoutPage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class DataOHM 
{
	WebDriver  wd;
	@BeforeTest
	public void opBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "./chromedriver");
		wd = new ChromeDriver();
		wd.get("https://opensource-demo.orangehrmlive.com/"); 
	}
	
	@Test(dataProvider = "dp")
  public void f(String un, String pw) 
  {			
	  OperationOHM_LoginPage op = new OperationOHM_LoginPage(wd);
	  OperationOHM_LogoutPage ol = new OperationOHM_LogoutPage(wd);
	  
	  wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  
	  op.loginProcess(un, pw);
	  try {
		ol.logoutProcess();
		System.out.println("Valid");
	} catch (Exception e) {
		System.out.println("Invalid");
	}
  }			//return type Object with 2d Array is mandatory
	  		//first array represents set of data
	  		//second array contains parameter value
  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "admin", "admin123" },
      new Object[] { "aa2", "b" },
    };
  }
  
  @AfterTest
  public void clBrowser()
  {
	  wd.close();
  }
 }
