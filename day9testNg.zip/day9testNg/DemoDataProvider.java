package day9testNg;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DemoDataProvider
{
  @Test(dataProvider = "dp")
  public void f(Integer n, String s) 
  {
	  System.out.println( n + "  " + s);
  }

  @DataProvider
  public Object[][] dp() 
  {			//return type Object with 2d Array is mandatory
	  		//first array represents set of data
	  		//second array contains parameter value
    return new Object[][] 
    {
      new Object[] { 1, "a" },
      new Object[] { 2, "b" },
    };
  }
}
