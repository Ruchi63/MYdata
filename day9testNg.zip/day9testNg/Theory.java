package day9testNg;

public class Theory
{
	/*
	 * 	TestNG---->Next Generation
	 * 	
	 * 		JUnit & NUnit---> unit testing--->
			is a type of sfotware testing means testing the smaller units of your application like classes and methods
	 * 		Junit-->Java Developer
	 * 		NUnit-->.Net Developer
	 * 
	 * 		It contains annotations[@]
	 * 		10 annotations
	 * 
	 *  	@BeforeSuite--->will run before execution of all test method in suite
	 *  	@BeforeClass--->will be executed before the first method of current class invoked
	 *  	@BeforeTest---->will be executed before the execution of all the test method
	 *  					available in class belongs to a folder
	 *  	@BeforeMethod--->will be executed before each test method
	 *  	@test====>can contain multiple @test
	 *  	@AfterMethod--->will be executed after each test method
	 *  	@AfterTest---->will be executed after the execution of all the test method
	 *  					available in class belongs to a folder
	 *  	@AfterClass--->will be executed after the first method of current class invoked
	 *  
	 *  	@AfterSuite--->will run after execution of all test method in suite
	 *  
	 *  
	 *  	Priority--->@Test which has low priority will execute first
	 *  		@Test execution is done in alphabetical order
	 *  
	 *  	Reports--->html format
	 *  
	 *  		1]	index.html
	 *  		2]	emailable-report.html
	 *  		3]	Default test.html
	 *  
	 *  	DataProvider--->achieve parameterization with @DataProvider
	 *  
	 *  	TestSuite--->is a collection of multiple test cases.With the help
	 *  			of TestNG XML Suite, we can execute multiple test cases
	 *  			at the same time.This is called as Parallel execution
	 *  			IT saves test execution time.
	 *  				
	 * 
	 */
	
}
