package day9testNg;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class AnnotationOHM 
{
	WebDriver wd;
	@BeforeSuite
	public void openBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "./chromedriver");
		wd = new ChromeDriver();
		wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	@BeforeClass
	public void loginProcess()
	{
		wd.get("https://opensource-demo.orangehrmlive.com/");
		wd.findElement(By.id("txtUsername")).sendKeys("admin");
		wd.findElement(By.name("txtPassword")).sendKeys("admin123");
		wd.findElement(By.className("button")).click();
	}
  @Test
  public void myInfo() 
  {
	  wd.findElement(By.id("menu_pim_viewMyDetails")).click();
  }
  @Test
  public void pim()
  {
	  wd.findElement(By.id("menu_pim_viewPimModule")).click();
  }
  @AfterClass
  public void logoutProcess()
  {
	  wd.findElement(By.partialLinkText("Welcome")).click();
	  wd.findElement(By.linkText("Logout")).click();
  }
   @AfterSuite
  public void closeBrowser()
  {
	  wd.close();
  }
}
